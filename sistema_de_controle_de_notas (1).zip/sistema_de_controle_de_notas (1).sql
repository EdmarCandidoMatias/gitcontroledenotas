-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 17-Jan-2024 às 02:19
-- Versão do servidor: 10.1.38-MariaDB
-- versão do PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistema_de_controle_de_notas`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `admin`
--

CREATE TABLE `admin` (
  `ID_admin` int(11) NOT NULL,
  `Nome_admin` varchar(255) DEFAULT NULL,
  `Usuario_admin` varchar(50) DEFAULT NULL,
  `Senha_admin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curso`
--

CREATE TABLE `curso` (
  `ID_curso` int(11) NOT NULL,
  `Nome_curso` varchar(255) DEFAULT NULL,
  `Cod_departamento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `curso`
--

INSERT INTO `curso` (`ID_curso`, `Nome_curso`, `Cod_departamento`) VALUES
(1, 'Engenharia Informarica', 1),
(2, 'Engenharia Industrical', 1),
(3, 'Telecomunicacao', 1),
(4, 'Ciencia da computacao', 1),
(5, 'Contabilidade e Gestao', 9),
(6, 'Enfermagem', 2),
(7, 'Bioqumica', 2),
(8, 'Farmacia', 2),
(9, 'Fisioterapia', 2),
(10, 'Ensino Primario', 5),
(11, 'Direito', 6),
(12, 'Relacoes internacionais', 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `departamento`
--

CREATE TABLE `departamento` (
  `Cod_Departamento` int(11) NOT NULL,
  `Nome_departamento` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `departamento`
--

INSERT INTO `departamento` (`Cod_Departamento`, `Nome_departamento`) VALUES
(1, 'Engenharia'),
(2, 'Ciencias da Saude'),
(3, 'Ciencia social'),
(4, 'Comunicacao social'),
(5, 'Educacao'),
(6, 'Juridico'),
(7, 'Administrativo'),
(9, 'Gestao e economia'),
(10, 'Linguas e literatura'),
(11, 'Ciencias exatas'),
(12, 'Psicologia');

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina`
--

CREATE TABLE `disciplina` (
  `ID_disciplina` int(11) NOT NULL,
  `Nome` varchar(255) DEFAULT NULL,
  `ID_professor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `disciplina`
--

INSERT INTO `disciplina` (`ID_disciplina`, `Nome`, `ID_professor`) VALUES
(1, 'Matematica Discreta', 3),
(2, 'Educacao fisica', 12),
(3, 'Computacao Grafica', 17),
(4, 'Algoritmo e Complexidade', 1),
(5, 'Analise Matematica', 19),
(6, 'Base de Dados', 2),
(7, 'Engenharia de Software', 2),
(8, 'Engenharia de Redes', 18),
(9, 'Linguagem de Programacao', 9),
(10, 'Linguagem de Programacao II', 9),
(11, 'Lingua Portuguesa', 5),
(12, 'Fisica', 16),
(13, 'Sistemas Digitais', 8),
(14, 'Gestao de Negocios', 11),
(15, 'Estatistica', 15);

-- --------------------------------------------------------

--
-- Estrutura da tabela `estudante`
--

CREATE TABLE `estudante` (
  `ID_estudante` int(11) NOT NULL,
  `Nome` varchar(255) DEFAULT NULL,
  `Data_nascimento` date DEFAULT NULL,
  `ID_curso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `estudante`
--

INSERT INTO `estudante` (`ID_estudante`, `Nome`, `Data_nascimento`, `ID_curso`) VALUES
(1, 'Edmar Matias', '2001-09-13', 1),
(2, 'Anatol Mario', '1998-01-09', 7),
(3, 'Svenia Domingos', '2001-08-02', 11),
(4, 'Conceicao Calunga', '2003-01-08', 3),
(5, 'Jose Masaki', '1999-01-23', 9),
(6, 'Jacinta Tchilala', '2001-01-02', 9),
(7, 'joao Lourenco', '2002-12-20', 6),
(8, 'Aguinaldo Cesar', '2001-01-31', 5),
(9, 'Adilson miguel', '1990-01-09', 8),
(10, 'Eduardo Lelo', '2002-01-02', 6),
(11, 'Humbelina Tenente', '2000-01-22', 5),
(12, 'Albnertina Domingos', '2001-01-09', 3),
(13, 'Eduardo Bovick', '2001-01-02', 6),
(14, 'Pembele Daniel', '1998-01-15', 2),
(15, 'Bruno Tunga', '1997-01-18', 8),
(16, 'Filipe Da Costa', '1998-01-17', 10),
(17, 'Vladimiro Pinto', '1996-01-22', 5),
(18, 'Sergio Garcia', '2002-01-15', 1),
(19, 'Arisatides Gongo', '1996-10-25', 2),
(20, 'Josiane Papel', '2000-12-07', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `matricula`
--

CREATE TABLE `matricula` (
  `ID_matricula` int(11) NOT NULL,
  `ID_estudante` int(11) DEFAULT NULL,
  `ID_disciplina` int(11) DEFAULT NULL,
  `Data_matricula` date DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `matricula`
--

INSERT INTO `matricula` (`ID_matricula`, `ID_estudante`, `ID_disciplina`, `Data_matricula`, `Status`) VALUES
(1, 1, 1, '2024-01-02', 'ATIVO'),
(2, 4, 15, '2024-01-18', 'ATIVO'),
(3, 10, 1, '2023-12-14', 'ATIVO'),
(5, 18, 12, '2023-10-11', 'ATIVO'),
(6, 5, 9, '2024-01-11', 'ATIVO'),
(7, 6, 6, '2024-01-06', 'ATIVO');

-- --------------------------------------------------------

--
-- Estrutura da tabela `nota`
--

CREATE TABLE `nota` (
  `ID_nota` int(11) NOT NULL,
  `ID_estudante` int(11) DEFAULT NULL,
  `ID_disciplina` int(11) DEFAULT NULL,
  `ID_periodo` int(11) DEFAULT NULL,
  `Nota` float DEFAULT NULL,
  `Data_registro` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `nota`
--

INSERT INTO `nota` (`ID_nota`, `ID_estudante`, `ID_disciplina`, `ID_periodo`, `Nota`, `Data_registro`) VALUES
(1, 9, 9, 1, 10, '2024-01-03'),
(2, 2, 6, 5, 19, '2024-01-01'),
(3, 16, 10, 3, 20, '2023-12-13'),
(4, 11, 13, 6, 7, '2024-01-18'),
(5, 20, 14, 3, 18, '2023-10-10'),
(6, 14, 12, 2, 9, '2024-01-18'),
(7, 17, 15, 3, 5, '2024-01-16');

-- --------------------------------------------------------

--
-- Estrutura da tabela `periodoletivo`
--

CREATE TABLE `periodoletivo` (
  `ID_periodo` int(11) NOT NULL,
  `Ano` varchar(10) DEFAULT NULL,
  `Semestre` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `periodoletivo`
--

INSERT INTO `periodoletivo` (`ID_periodo`, `Ano`, `Semestre`) VALUES
(1, 'I Ano', 'I Semestre'),
(2, 'II Ano', 'II Semestre'),
(3, 'III Ano', 'I Semestre'),
(4, 'IV Ano', 'I Semestre'),
(5, 'III Ano', 'II Semestre'),
(6, 'V Ano', 'I Semestre'),
(7, 'V Ano', 'II Semestre');

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor`
--

CREATE TABLE `professor` (
  `ID_professor` int(11) NOT NULL,
  `Nome_professor` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `professor`
--

INSERT INTO `professor` (`ID_professor`, `Nome_professor`) VALUES
(1, 'Artaxerxes miguel '),
(2, 'Antunes Miguel'),
(3, 'Futi Simao'),
(4, 'Antonio Panda'),
(5, 'joao jose'),
(6, 'daniel carvalho'),
(7, 'Eduardo Francisco'),
(8, 'Osvaldo Firmino'),
(9, 'Edgar Barros'),
(10, 'Simao antonio'),
(11, 'rafael marcos'),
(12, 'Ana Maria'),
(13, 'isabel Monavango'),
(14, 'Fernando Tavares'),
(15, 'Svenia Canga'),
(16, 'Mario Matias'),
(17, 'Eduardo Massala'),
(18, 'Benedito Kiala'),
(19, 'Adilson Pedro'),
(20, 'Nercia Pedro');

-- --------------------------------------------------------

--
-- Estrutura da tabela `turma`
--

CREATE TABLE `turma` (
  `ID_turma` int(11) NOT NULL,
  `Nome_turma` varchar(255) DEFAULT NULL,
  `ID_curso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `turma`
--

INSERT INTO `turma` (`ID_turma`, `Nome_turma`, `ID_curso`) VALUES
(1, 'EIM1', 1),
(2, 'EIM2', 1),
(3, 'EIM3', 1),
(4, 'EIM4', 1),
(5, 'EIM5', 1),
(6, 'FRM1', 8),
(7, 'FRM2', 8),
(8, 'FRM3', 8),
(9, 'BQM', 7),
(10, 'RLI', 12),
(11, 'ENF', 6),
(12, 'TLC', 3),
(13, 'ENPR', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID_admin`),
  ADD UNIQUE KEY `Usuario_admin` (`Usuario_admin`);

--
-- Indexes for table `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`ID_curso`),
  ADD KEY `Cod_departamento` (`Cod_departamento`);

--
-- Indexes for table `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`Cod_Departamento`);

--
-- Indexes for table `disciplina`
--
ALTER TABLE `disciplina`
  ADD PRIMARY KEY (`ID_disciplina`),
  ADD KEY `ID_professor` (`ID_professor`);

--
-- Indexes for table `estudante`
--
ALTER TABLE `estudante`
  ADD PRIMARY KEY (`ID_estudante`),
  ADD KEY `ID_curso` (`ID_curso`);

--
-- Indexes for table `matricula`
--
ALTER TABLE `matricula`
  ADD PRIMARY KEY (`ID_matricula`),
  ADD KEY `ID_estudante` (`ID_estudante`),
  ADD KEY `ID_disciplina` (`ID_disciplina`);

--
-- Indexes for table `nota`
--
ALTER TABLE `nota`
  ADD PRIMARY KEY (`ID_nota`),
  ADD KEY `ID_estudante` (`ID_estudante`),
  ADD KEY `ID_disciplina` (`ID_disciplina`),
  ADD KEY `ID_periodo` (`ID_periodo`);

--
-- Indexes for table `periodoletivo`
--
ALTER TABLE `periodoletivo`
  ADD PRIMARY KEY (`ID_periodo`);

--
-- Indexes for table `professor`
--
ALTER TABLE `professor`
  ADD PRIMARY KEY (`ID_professor`);

--
-- Indexes for table `turma`
--
ALTER TABLE `turma`
  ADD PRIMARY KEY (`ID_turma`),
  ADD KEY `ID_curso` (`ID_curso`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departamento`
--
ALTER TABLE `departamento`
  MODIFY `Cod_Departamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `curso`
--
ALTER TABLE `curso`
  ADD CONSTRAINT `curso_ibfk_1` FOREIGN KEY (`Cod_departamento`) REFERENCES `departamento` (`Cod_Departamento`);

--
-- Limitadores para a tabela `disciplina`
--
ALTER TABLE `disciplina`
  ADD CONSTRAINT `disciplina_ibfk_1` FOREIGN KEY (`ID_professor`) REFERENCES `professor` (`ID_professor`);

--
-- Limitadores para a tabela `estudante`
--
ALTER TABLE `estudante`
  ADD CONSTRAINT `estudante_ibfk_1` FOREIGN KEY (`ID_curso`) REFERENCES `curso` (`ID_curso`);

--
-- Limitadores para a tabela `matricula`
--
ALTER TABLE `matricula`
  ADD CONSTRAINT `matricula_ibfk_1` FOREIGN KEY (`ID_estudante`) REFERENCES `estudante` (`ID_estudante`),
  ADD CONSTRAINT `matricula_ibfk_2` FOREIGN KEY (`ID_disciplina`) REFERENCES `disciplina` (`ID_disciplina`);

--
-- Limitadores para a tabela `nota`
--
ALTER TABLE `nota`
  ADD CONSTRAINT `nota_ibfk_1` FOREIGN KEY (`ID_estudante`) REFERENCES `estudante` (`ID_estudante`),
  ADD CONSTRAINT `nota_ibfk_2` FOREIGN KEY (`ID_disciplina`) REFERENCES `disciplina` (`ID_disciplina`),
  ADD CONSTRAINT `nota_ibfk_3` FOREIGN KEY (`ID_periodo`) REFERENCES `periodoletivo` (`ID_periodo`);

--
-- Limitadores para a tabela `turma`
--
ALTER TABLE `turma`
  ADD CONSTRAINT `turma_ibfk_1` FOREIGN KEY (`ID_curso`) REFERENCES `curso` (`ID_curso`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
